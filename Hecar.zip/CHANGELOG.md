# 0.5.4

Waning blessing activates at the start of round rather than turn (text might not update appropriately unless Balance Patch is active. This will be fixed with the next version of Obeliskial Essentials)

Fixed compatibility issue with Starlit Scourge and Too Many Perks

# 0.5.3

Fixed a bug where the bonus Shield/Block from Scourge would continually increase.

# 0.5.2

Updated text description on Shattered Soul

Fixed an issue with regen procing Overheal every frame

Fixed an issue with Eclipse Shield not improving Shield/Block until level 5.

# 0.5.1

Removed the Testing text from Flash Heal

Reflection is no longer craftable   

# 0.5.0

Initial pre-release

# 0.4.0

Reworded some traits, fixed some minor bugs, got overheal working, and got 50% reduction on Scourge working.

# 0.3.0

Bug fixes for traits

# 0.2.0

Reworked all traits and enchantments

# 0.1.0

Initial concept.