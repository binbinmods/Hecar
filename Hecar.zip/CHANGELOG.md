# 0.3.0

Bug fixes for traits

# 0.2.0

Reworked all traits and enchantments

# 0.1.0

Initial concept.